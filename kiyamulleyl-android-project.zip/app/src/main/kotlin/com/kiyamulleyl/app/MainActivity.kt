package com.kiyamulleyl.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private lateinit var webView: WebView

    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val API_HOST = "imsakiyem.com"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.setBackgroundColor(Color.parseColor("#1C2A56"))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false
        setContentView(webView)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                if (request == null) return null
                val uri = request.url
                val host = uri.host ?: ""

                // Uygulamanın kendi dosyaları (assets içindeki index.html)
                if (host == APP_HOST) {
                    val local = assetLoader.shouldInterceptRequest(uri)
                    if (local != null) return local
                    // Olmayan dosya (sw.js, manifest.json vb.): ağa gitmeden hemen 404 ver
                    return WebResourceResponse(
                        "text/plain", "utf-8", 404, "Not Found",
                        emptyMap(), ByteArrayInputStream(ByteArray(0))
                    )
                }

                // Namaz vakti API'si: CORS kaygısı olmasın diye istek burada yapılır
                if (request.method == "GET" &&
                    uri.scheme == "https" &&
                    (host == API_HOST || host.endsWith(".$API_HOST"))
                ) {
                    return proxyApi(request, uri)
                }

                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = true

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recreate()
                return true
            }
        }

        webView.loadUrl("https://$APP_HOST/assets/index.html")
    }

    // Hata olursa null döner; bu durumda WebView isteği kendisi yapmayı dener.
    private fun proxyApi(request: WebResourceRequest, uri: Uri): WebResourceResponse? {
        try {
            val conn = URL(uri.toString()).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.instanceFollowRedirects = true
            for (key in listOf("Accept", "Accept-Language", "User-Agent")) {
                val value = request.requestHeaders[key]
                if (value != null) conn.setRequestProperty(key, value)
            }

            val code = conn.responseCode
            if (code < 200 || code > 599 || code in 300..399) {
                conn.disconnect()
                return null
            }

            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val mime = (conn.contentType ?: "application/json").substringBefore(';').trim()
            val reason = conn.responseMessage
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Cache-Control" to "no-store"
            )
            return WebResourceResponse(
                mime,
                "utf-8",
                code,
                if (reason.isNullOrEmpty()) "OK" else reason,
                headers,
                stream ?: ByteArrayInputStream(ByteArray(0))
            )
        } catch (e: Exception) {
            return null
        }
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
