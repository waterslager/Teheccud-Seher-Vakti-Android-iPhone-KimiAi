package com.kiyamulleyl.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private val handler = Handler(Looper.getMainLooper())

    private var splashDone = false
    private var showingError = false

    companion object {
        private const val START_URL =
            "https://waterslager.github.io/Teheccud-Seher-Vakti-Android-iPhone-KimiAi/"
        private const val ALLOWED_HOST = "waterslager.github.io"
        private const val SPLASH_MAX_MS = 2500L
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash: sayfa yüklenene (en fazla 2,5 sn) kadar ekranda kalır
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !splashDone }
        handler.postDelayed({ splashDone = true }, SPLASH_MAX_MS)

        webView = WebView(this)
        webView.setBackgroundColor(Color.parseColor("#1C2A56"))
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        webView.isHorizontalScrollBarEnabled = false

        swipe = SwipeRefreshLayout(this)
        swipe.addView(
            webView,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        swipe.setColorSchemeColors(Color.parseColor("#60A5FA"))
        swipe.setProgressBackgroundColorSchemeColor(Color.parseColor("#0E2043"))
        swipe.setDistanceToTriggerSync((80 * resources.displayMetrics.density).toInt())
        swipe.setOnRefreshListener { refreshPage() }
        setContentView(swipe)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val host = request?.url?.host ?: return true
                // Sadece kendi sitenin sayfaları açılır, başka adresler engellenir
                return host != ALLOWED_HOST
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                swipe.isRefreshing = false
                splashDone = true
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true &&
                    error?.errorCode != WebViewClient.ERROR_UNKNOWN
                ) {
                    showErrorPage()
                }
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: RenderProcessGoneDetail?
            ): Boolean {
                recreate()
                return true
            }
        }

        webView.loadUrl(START_URL)
    }

    private fun showErrorPage() {
        showingError = true
        splashDone = true
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>" +
            "<body style='margin:0;background:#1c2a56;color:#a5b4fc;font-family:sans-serif;" +
            "display:flex;align-items:center;justify-content:center;height:100vh;text-align:center'>" +
            "<div>Bağlantı yok<br><small>Yenilemek için ekranı aşağı çekin</small></div>" +
            "</body></html>"
        webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    // Aşağı çekince: önbellekleri temizleyip siteyi baştan yükler
    private fun refreshPage() {
        handler.postDelayed({ swipe.isRefreshing = false }, 6000)
        if (showingError) {
            showingError = false
            webView.loadUrl(START_URL)
            return
        }
        webView.clearCache(true)
        webView.evaluateJavascript(
            "(async function(){ try { var k = await caches.keys(); " +
                "await Promise.all(k.map(function(x){ return caches.delete(x); })); } " +
                "catch(e) {} location.reload(); })();",
            null
        )
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!showingError && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.destroy()
        super.onDestroy()
    }
}
